// حساب تكلفة التوصيل تلقائيًا
document.getElementById('region').addEventListener('change', function () {
    var selectedOption = this.options[this.selectedIndex];
    var price = selectedOption.getAttribute('data-price');

    if (price) {
        document.getElementById('price').textContent = price;
        document.getElementById('delivery-price').classList.remove('hidden');
    } else {
        document.getElementById('delivery-price').classList.add('hidden');
    }
});

// وظيفة إرسال الطلب عبر واتساب عند الضغط على زر "تأكيد الطلب"
document.getElementById('confirm-order').addEventListener('click', function () {
    var name = document.getElementById('customer-name').value;
    var time = document.getElementById('delivery-time').value;
    var details = document.getElementById('order-details').value;
    var address = document.getElementById('address').value;
    var phone = document.getElementById('phone').value;
    var region = document.getElementById('region').value;
    var price = document.getElementById('price').textContent;

    if (name && details && address && phone && region) {
        var message = `👤 *اسم العميل:* ${name}%0A
        ⏳ *وقت التسليم:* ${time}%0A
        🛒 *تفاصيل الطلب:* ${details}%0A
        📍 *العنوان:* ${address}%0A
        📌 *المنطقة:* ${region} (%2B${price} جنيه توصيل)%0A
        📞 *رقم الهاتف:* ${phone}`;
        
        var whatsappUrl = `https://wa.me/201200450151?text=${message}`;
        window.open(whatsappUrl, '_blank');
    } else {
        alert("❌ يرجى ملء جميع البيانات قبل إرسال الطلب!");
    }
});
